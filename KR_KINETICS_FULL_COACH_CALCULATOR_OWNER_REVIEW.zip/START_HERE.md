# Calculateur coach KR Kinetics — examen propriétaire

## Démarrage (une commande)

Depuis la racine du dépôt (après `npm install`) :

```bash
npm run coach:preview
```

Puis ouvrir exactement :

**http://127.0.0.1:4188/**

Le dossier `coach-calculator/` de ce ZIP contient l'application déjà buildée. Vous pouvez aussi servir ce dossier avec n'importe quel serveur statique sur le port 4188.

## Contenu de ce paquet

| Élément | Chemin |
|---|---|
| Application | `coach-calculator/` |
| Capture desktop 1440 | `screenshots/desktop-1440.png` |
| Capture tablette 768 | `screenshots/tablet-768.png` |
| Capture mobile 390 | `screenshots/mobile-390.png` |
| Profil Xavier (JSON) | `xavier-profile-export.json` |
| Plan texte | `xavier-plan-text.txt` |
| PDF client FR | `xavier-plan-client-fr.pdf` |
| PDF client EN | `xavier-plan-client-en.pdf` |
| Tableau équivalents 287 | `equivalents-client-287.pdf` |
| Rapport de parité | `parity-report.md` |
| Checklist P0 | `CHECKLIST_PARITE_FONCTIONNELLE.md` |
| Rapport des tests | `test-report.md` |
| Hashes avant | `protected-hashes-before.json` |
| Hashes après | `protected-hashes-after.json` |
| Capture summary | `capture-summary.json` |

## Notes produit

- Outil privé coach — le client ne reçoit que le PDF portions + le tableau des équivalents.
- Mode A (production) par défaut ; D/A désactivé (`FEATURE_DA_ENABLED = false`).
- Source nutritionnelle : 287 aliments vérifiés, hashes protégés inchangés.
